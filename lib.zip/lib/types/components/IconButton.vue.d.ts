import { Vue } from "vue-property-decorator";
export default class IconButton extends Vue {
    private id;
    private icon;
    private iconOn;
    private element;
    private on;
    changeOn(): void;
    mounted(): void;
}
