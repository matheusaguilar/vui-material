import { Vue } from "vue-property-decorator";
export default class ChipGrid extends Vue {
    private id;
    private element;
    mounted(): void;
}
