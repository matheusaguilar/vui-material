import { Vue } from "vue-property-decorator";
export default class List extends Vue {
    private id;
    private element;
    mounted(): void;
}
