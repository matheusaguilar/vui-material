import { Vue } from "vue-property-decorator";
export default class LayoutGridInner extends Vue {
    private id;
    private element;
    mounted(): void;
}
