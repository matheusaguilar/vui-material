import { Vue } from "vue-property-decorator";
export default class LayoutGrid extends Vue {
    private id;
    private element;
    mounted(): void;
}
