export declare class VComponent {
    mdc: any;
    dom: any;
    ripple: any;
    dataid: string;
    mergeAttributes(defaultData: any, data: any): any;
}
