import { Vue } from "vue-property-decorator";
export default class Style extends Vue {
}
